// src/hooks/queries/useAssignmentQueries.ts

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { assignmentsService } from '@/services';
import { QUERY_KEYS } from '@/lib/constants';
import type {
  AssignPatientRequest,
  RevokeAssignmentRequest,
} from '@/types/assignment';

/**
 * Hook to get all available specialities
 */
export function useSpecialities() {
  return useQuery({
    queryKey: ['specialities'],
    queryFn: () => assignmentsService.getSpecialities(),
    staleTime: 30 * 60 * 1000, // 30 minutes - specialities rarely change
  });
}

/**
 * Hook to get assigned patients with history (Doctor only)
 */
export function useMyPatients() {
  return useQuery({
    queryKey: QUERY_KEYS.MY_PATIENTS,
    queryFn: () => assignmentsService.getMyPatients(),
    staleTime: 5 * 60 * 1000,
  });
}

/**
 * Hook to get assigned doctors with history (Patient only)
 */
export function useMyDoctors() {
  return useQuery({
    queryKey: QUERY_KEYS.MY_DOCTORS,
    queryFn: () => assignmentsService.getMyDoctors(),
    staleTime: 5 * 60 * 1000,
  });
}

/**
 * Hook to get patient profile by email (Doctor only)
 */
export function usePatientProfileByEmail(email: string | undefined) {
  return useQuery({
    queryKey: ['patientProfile', email],
    queryFn: () => assignmentsService.getPatientByEmail(email!),
    enabled: !!email,
    staleTime: 5 * 60 * 1000,
  });
}

/**
 * Hook to assign a patient (Doctor only)
 */
export function useAssignPatient() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: AssignPatientRequest) =>
      assignmentsService.assignPatient(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.MY_PATIENTS });
    },
  });
}

/**
 * Hook to revoke assignment (Doctor only)
 */
export function useRevokeAssignment() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: RevokeAssignmentRequest) =>
      assignmentsService.revokeAssignment(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.MY_PATIENTS });
    },
  });
}

/**
 * Hook to prefetch patient profile by email
 */
export function usePrefetchPatientProfile() {
  const queryClient = useQueryClient();

  return (email: string) => {
    queryClient.prefetchQuery({
      queryKey: ['patientProfile', email],
      queryFn: () => assignmentsService.getPatientByEmail(email),
      staleTime: 5 * 60 * 1000,
    });
  };
}
